/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class Functions {
    
    public Interface minterface;
    public Factory factory;
    
    public Functions(Factory factory){
        
        this.minterface = minterface;
        this.factory = factory;
        
    }
    
    public void start_factory(){
        factory.start();
    }
    
    public void set_mierda(){
        System.out.println("malditaseaaaaaaaaaaaaaa");
        }
    
}
