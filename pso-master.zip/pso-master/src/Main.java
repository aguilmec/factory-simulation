
import java.util.concurrent.Semaphore;




public class Main {

    /**
     * @param args the command line arguments
     */
    

    
    
    public static void main(String[] args) {
       
        

        Interface minterface = new Interface();
        minterface.setVisible(true);
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
